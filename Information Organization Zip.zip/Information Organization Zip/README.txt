﻿‎INFM600 – Information Organization____________________________________________________________________________________

Dataset Description:      

The focal dataset for this project shows the number of elementary, middle, and high schools in Howard County. The dataset provides the school names and addresses for all schools inside the county. The datasets show 41 elementary schools, 21 middle schools, and 13 high schools. For this project in particular we are focused on the schools in the Columbia Association (CA) boundaries. The processing document will describe how the datasets are to be combined into one focal dataset.      
• Howard County, Maryland. (2015). Schools - Elementary [Data file]. Available from https://data.howardcountymd.gov/.
• Howard County, Maryland. (2015). Schools - Middle [Data file]. Available from https://data.howardcountymd.gov/.
• Howard County, Maryland. (2015). Schools - High [Data file]. Available from https://data.howardcountymd.gov/.      

One additional dataset to be combined with the focal dataset shows the number of CA pool sites. This dataset provides names and addresses for all of the CA pools spread throughout the villages. CA currently has 24 pools located throughout the villages.       
• Howard County, Maryland. (2015). Pools – Columbia Association [Data file]. Available from https://data.howardcountymd.gov/.      

The second dataset to be combined with the focal dataset shows Park Pavilions located on Howard County parkland. This dataset provides the names of the parks, along with several descriptive columns like rentable space, parks with a Gazebo, fireplace, as well as latitude and longitude location points. This dataset shows 30 Park Pavilions located in Howard County. For this project we are focused on the ones located within the CA boundaries.       

• Howard County, Maryland. (2015). Park Pavilions [Data file]. Available from https://data.howardcountymd.gov/.

Process Documentation File:

Process Documentation.docx.

Questions:

1. Do public schools within the CA boundaries have nearby access to recreational facilities like parks and pools for after school activities to incentivize further learning and healthy living? 

2. How can CA target specific parks closest to local schools as a means of getting kids involved in healthy physical fitness activities through before, after school and summer programs?
Reporting: 

Reporting:

A simple map can be made easily with icons showing where the schools are located, (which can be separated into elementary, middle, and high schools) along with another icon for the CA pools. The Howard County, Maryland data download page has a very simple and easy way to map the dataset by simply clicking on the “View Map” option next to the available dataset. From there a number of functions are available to manipulate how the viewer sees the dataset. A more detailed explanation is provided in the Processing Documentation section of this project. 
The dataset makes it easy to see which schools certain CA pools should target with video for afterschool and weekend activities. Short and punchy videos with flashy highlights of the events available at CA pools on replay in the school cafeterias may be a great tool to get more kids active and productive. On the same or following video a to the point message about how to safely get there from the school, a way a child may get to their own daycare/swimming lessons a few times a week. Of course, it does not have to be solely about after school programs, but special events over the weekends, yearly major events video can be promoting. And additional datasets provided by Howard County, Maryland Data Download and Viewer page can be added to show other things like parks nearest to each school, for example. 

Dataset Citation:

• Marciano, F. S. (2015). Merged Howard County Schools & Columbia Association Pools Datasets. [Data file]. License:      

License:

This work is licensed under the Creative Commons Attribution 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/.